#-*- coding: UTF-8 -*-
import os
import sys
import json
import codecs
import shutil
import scipy.io as sio
import scipy.signal
import numpy as np
import joblib
import pdb
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import scipy.signal as SIG
import logging
from contextlib import closing
from multiprocessing.dummy import Pool as Theradpool
from multiprocessing import Pool
from matplotlib import rcParams
from collections import OrderedDict
from random import randrange
from random import seed
def pro_signal(raw_signal):
    raw_signal['III'] = raw_signal['II'] - raw_signal['I']
    raw_signal['aVR'] = -(raw_signal['I'] + raw_signal['II']) / float(2)
    raw_signal['aVL'] = raw_signal['I'] - raw_signal['II'] / float(2)
    raw_signal['aVF'] = raw_signal['II'] - raw_signal['I'] / float(2)
    for key in raw_signal:
        tmp = raw_signal[key]
        if isinstance(tmp, str):
            continue
        if isinstance(tmp, list):
            continue
        raw_signal[key] = (tmp.tolist())[0]
    return
def ConvertLabel(label):
    '''Convert random forest label to figure label.'''
    if label == 'T':
        mker = 'wo'
        mkeredge = 'r'
    elif label == 'R':
        mker = 'wo'
        mkeredge = 'g'
    elif label == 'P':
        mker = 'wo'
        mkeredge = 'b'
    elif label == 'Tonset':
        mker = 'w<'
        mkeredge = 'r'
    elif label == 'Toffset':
        mker = 'w>'
        mkeredge = 'r'
    elif label == 'Ronset':
        mker = 'w<'
        mkeredge = 'g'
    elif label == 'Roffset':
        mker = 'w>'
        mkeredge = 'g'
    elif label == 'Ponset':
        mker = 'w<'
        mkeredge = 'b'
    elif label == 'Poffset':
        mker = 'w>'
        mkeredge = 'b'
    else:  # white
        mker = 'w.'
        mkeredge = 'w.'
    return mker,mkeredge
def plot_ECG(II_label_pos,raw_signal,ID,figure_folder):
    key_point=II_label_pos
    figure_path=os.path.join(figure_folder,str(ID)+'limbs_lead.png')
    if os.path.isfile(figure_path)==False:
       plt.figure(1,figsize=(60, 30), dpi=100)
       plt.clf()
       lead_list = ['I', 'II', 'III', 'aVR', 'aVF', 'aVL']
       for i in range(len(lead_list)):
           lead = lead_list[i]
           plt.subplot(6, 1, i + 1)
           lead_signal = raw_signal[lead]
           plt.xticks(range(0, 6000, 1000), [0, 2, 4, 6, 8, 10],fontsize=40)
           plt.xlabel('time/s',fontsize=40,horizontalalignment='right')
           plt.yticks(fontsize=25 )
           plt.ylabel('amp/mv',fontsize=25,verticalalignment='top',rotation='vertical')
           plt.plot(lead_signal, color='k', label=lead, linewidth=2.5, alpha=0.9)
           for key in key_point.keys():
               key_point[key] = [x for x in key_point[key] if x < len(lead_signal)]
               lead_amp_list = [lead_signal[int(x)] for x in key_point[key]]
               mker, mkeredge = ConvertLabel(key)
               plt.plot(key_point[key], lead_amp_list, mker, markeredgecolor=mkeredge, markersize=6.0, label=key,linewidth=1, alpha=0.9)
           for xx in range(0, 5020, 20):
               if xx%100==0:
                  plt.plot([xx, xx], [min(lead_signal) - 0.5, max(lead_signal) + 0.5], color='r', linestyle='-',linewidth=3, alpha=0.6)
               else:
                    plt.plot([xx, xx], [min(lead_signal) - 0.5, max(lead_signal) + 0.5], color='r', linestyle='-',linewidth=2, alpha=0.4)
           for yy in range(int((min(lead_signal) - 0.5) / 0.1), int((max(lead_signal) + 0.5) / 0.1)+1):
               kk = 0.1 * yy
               if yy%5 == 0 and yy!=0:
                  plt.plot([0, 5000], [kk, kk], color='r', linestyle='-', linewidth=3.0, alpha=0.6)
               else:
                    if yy!=0:
                       plt.plot([0, 5000], [kk,kk], color='r', linestyle='-', linewidth=2.0, alpha=0.4)
                    else:
                         plt.plot([0, 5100], [0, 0], color='r', linestyle='-', linewidth=3.0, alpha=0.6)
           plt.title(lead,fontsize=40)
       plt.suptitle(str(ID),fontsize=40)
   # figure_path=os.path.join('/home/lab/Programm/diagnoise/result/random_48122/random_48122_plot',str(ID)+'chest_lead.png')
       plt.savefig(figure_path)

    figure_path=os.path.join(figure_folder,str(ID)+'chest_lead.png')
    if os.path.isfile(figure_path)==False:
       plt.figure(1,figsize=(60, 30), dpi=100)
       plt.clf()
       lead_list = ['V1', 'V2', 'V3', 'V4', 'V5', 'V6']
       for i in range(len(lead_list)):
           lead = lead_list[i]
           plt.subplot(6, 1, i + 1)
           lead_signal = raw_signal[lead]
           plt.xticks(range(0, 6000, 1000), [0, 2, 4, 6, 8, 10],fontsize=40)
           plt.xlabel('time/s',fontsize=40,horizontalalignment='right')
           plt.yticks(fontsize=25 )
           plt.ylabel('amp/mv',fontsize=25,verticalalignment='top',rotation='vertical')
           plt.plot(lead_signal, color='k', label=lead, linewidth=2.5, alpha=0.9)
           for key in key_point.keys():
               key_point[key] = [x for x in key_point[key] if x < len(lead_signal)]
               lead_amp_list = [lead_signal[int(x)] for x in key_point[key]]
               mker, mkeredge = ConvertLabel(key)
               plt.plot(key_point[key], lead_amp_list, mker, markeredgecolor=mkeredge, markersize=6.0, label=key,linewidth=1, alpha=0.9)
           for xx in range(0, 5020, 20):
               if xx%100==0:
                  plt.plot([xx, xx], [min(lead_signal) - 0.5, max(lead_signal) + 0.5], color='r', linestyle='-',linewidth=3, alpha=0.6)
               else:
                    plt.plot([xx, xx], [min(lead_signal) - 0.5, max(lead_signal) + 0.5], color='r', linestyle='-',linewidth=2, alpha=0.4)
           for yy in range(int((min(lead_signal) - 0.5) / 0.1), int((max(lead_signal) + 0.5) / 0.1)+1):
               kk = 0.1 * yy
               if yy%5 == 0 and yy!=0:
                  plt.plot([0, 5000], [kk, kk], color='r', linestyle='-', linewidth=3.0, alpha=0.6)
               else:
                    if yy!=0:
                       plt.plot([0, 5000], [kk,kk], color='r', linestyle='-', linewidth=2.0, alpha=0.4)
                    else:
                         plt.plot([0, 5100], [0, 0], color='r', linestyle='-', linewidth=3.0, alpha=0.6)
           plt.title(lead,fontsize=40)
       plt.suptitle(str(ID),fontsize=40)
   # figure_path=os.path.join('/home/lab/Programm/diagnoise/result/random_48122/random_48122_plot',str(ID)+'chest_lead.png')
       plt.savefig(figure_path)

def func(data):
     ID=data['id']
     rec_path = data['mat_rhythm']
     print ID
     if ID in [56022]:
         return
     raw_signal = sio.loadmat(rec_path)
     pro_signal(raw_signal)
     json_path = os.path.join('/home/share/ZGCDemo/hyf/keypoint_v1/', str(ID) + '.json')
     if os.path.isfile(json_path):
        with codecs.open(json_path, 'r', 'utf8') as fin:
             fin_label = json.load(fin)
        II_label_pos = fin_label['II_label_pos']
        figure_folder='/home/share/ZGCDemo/hyf/ECG_pic_v1'
        plot_ECG(II_label_pos,raw_signal,ID,figure_folder)

def plot_toatla48122():
    with codecs.open('/home/share/ZGCDemo/hyf/total_48122.json','r',encoding='utf-8') as fin:
         FIN=json.load(fin)
    data=FIN['data']
    for i in range(len(data)):
        func(data[i])
    try:
        with closing(Pool(11)) as p:
             p.map(func,data,len(data)/11)
    except Exception as e:
               logging.error("error_detail:{}".format(str(e)),exc_info=True)





if __name__=='__main__':
    data_path='/home/share/ZGCDemo/hyf/total_48122.json'
    #plot_new_randomwalk(data_path)
    plot_toatla48122()
    pass


